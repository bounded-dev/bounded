export declare const bounded: true;
